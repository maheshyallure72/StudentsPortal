<?php

class config  
{	
	function __construct() {
		$this->host = "localhost";
		$this->user  = "root";
		$this->pass = "passwd";
		$this->db_name = "student_portal";
		$this->page_record_count = 2;
	}
}
?>