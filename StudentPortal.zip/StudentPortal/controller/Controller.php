<?php
	interface Controller
	{
		//Implement function in all the controllers for request handling
		public function requestHandler();
	}
?>