<?php
  require_once 'model/courseModel.php';
  require_once 'model/course.php';
  require_once "config.php";    
  require_once "Controller.php";
  $message = ""; 
  $error_msg = "";
  $course = NULL;
  $action = "";
  $pageno = $total_pages = "";
	class courseController  implements Controller
	{
 		function __construct() 
		{          
			$this->obcourse =  new courseModel();
      $course = new course();
      $this->config = new config;  
      $error_msg = '';
		}
    // handler request
    public function requestHandler() 
    {
      global $action,$error_msg,$course;
      $todo = isset($_GET['todo']) ? $_GET['todo'] : NULL;
      $action = "index.php?route=course&todo=add";
      try
      {
        switch ($todo) 
        {
          case 'add' :
              $this->addCourse();
            break;            
          case 'update':
            $this->updateCourse();
            break;        
          case 'delete' :         
            $this->deleteCourse();
            break;                
          default:
              $this->courseList();
        }
      }catch(Exception $e){
        $error_msg="Error description: ".$e->getMessage();                  
        $this->courseList();
      }
    } 	

    //  validation of Course record data
		public function validationFormdata($course)
        {    $error=false;
            // Validate fname        
            if(empty($course->course_name)){
                $course->course_name_msg = "Field is empty.";$error=true;
            } elseif(!filter_var($course->course_name, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z ]{1,30}+[0-9]*[a-zA-Z ]*+$/")))) {
                $course->course_name_msg = "Invalid entry.";$error=true;
            }else{$course->course_name_msg ="";}   
            //Validate lname            
            if(empty($course->course_details)){
                $course->course_details_msg = "Field is empty.";$error=true;     
            }
            else{$course->course_details_msg ="";}
            return $error;
        }
        // add course record
		public function addCourse()
		{
      global $message,$course,$error_msg;
            try{
                $course = new course();
                  // read form value
                  $course->course_name = trim($_POST['cname']);
                  $course->course_details = trim($_POST['cdetails']);
                  //call validation
                  if(!$this->validationFormdata($course))
                  {   
                      //Check course to avoid duplicate entry
                      if($this->obcourse->isCourseExist($course->course_name)==0)
                      {
                        // insert course record            
                        $pid = $this->obcourse->addCourse($course);
                        if($pid>0){	
                          $course = NULL;
                          $message= "Course added successfully!";
                        }else{
                          $error_msg= "Somthing is wrong..., try again.";
                        }
                      }else{
                        $course->contact_no_msg = "Duplicate course!";
                        $error_msg= "Course already exist!";
                      }
                  }else
                  {    
                      $error_msg="Error in the form input!";
                  }
                  $this->courseList();
            }catch (Exception $e) 
            {
                throw $e;
            }
        }

        // update course record
    public function updateCourse()
    {
      global $message,$course,$error_msg,$action;
            try{
                $course = new course();
                  // read form value
                  $course->course_name = trim($_POST['cname']);
                  $course->course_details = trim($_POST['cdetails']);
                  $course->course_id = trim($_POST['id']);
                  if($course->course_id)
                  {
                    //call validation
                    if(!$this->validationFormdata($course))
                    {   
                          // insert course record            
                          $resp = $this->obcourse->updateCourse($course);
                          if($resp){ 
                            $course = NULL;
                            $message= "course updated successfully!";
                          }else{
                            $error_msg= "Somthing is wrong..., try again.";
                          }
                    }else
                    {    
                        $error_msg="Error in the form input!";
                    }
                  }else{
                    $error_msg="Invalid record!";
                  }
                  $this->courseList();
            }catch (Exception $e) 
            {
                $error_msg=$e->getMessage();
                $this->courseList();
            }
        }
    public function deleteCourse()
    {
      global $message,$course,$error_msg;
            try{
                $course = new course();
                  // read form value
                  $course_id = trim($_GET['id']);
                  if($course_id)
                  {
                      // insert course record            
                      $resp = $this->obcourse->deleteCourse($course_id);
                      if($resp){ 
                          $message= "course deleted successfully!";
                      }else{
                          $error_msg= "Error while deleting record!";
                      }
                  }else{
                    $error_msg=" Invalid record!";
                  }
                  $this->courseList();
            }catch (Exception $e) 
            {
                throw $e;
            }
      }
        public function courseList(){
            global $message,$course,$error_msg,$action,$pageno,$total_pages;
            $result = array();
            try{
              if (isset($_GET['pageno'])) {
                  $pageno = $_GET['pageno'];
              } else {
                  $pageno = 1;
              }
              $offset = ($pageno-1) * $this->config->page_record_count;

              $total_rows=$this->obcourse->getCourseCount();
              $total_pages = ceil($total_rows / $this->config->page_record_count);
              $result=$this->obcourse->getCourses($offset,$this->config->page_record_count);

              include "view/courseList.php";                                        
            }catch(Exception $e){
              $error_msg="Error description: ".$e->getMessage();                  
              include "view/courseList.php";
            }
        }
    }
		
	
?>