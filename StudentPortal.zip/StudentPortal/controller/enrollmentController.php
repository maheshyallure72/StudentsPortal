<?php
  require_once 'model/enrollmentModel.php';
  require_once 'model/enrollment.php';
  require_once 'model/studentsModel.php';
  require_once 'model/courseModel.php';
  require_once "Controller.php";
  require_once "config.php";  
  $message = ""; 
  $error_msg = "";
  $enrollment = NULL;
  $action = "";
  $pageno = $total_pages = "";
	class enrollmentController  implements Controller
	{
 		function __construct() 
		{          
			$this->obenrollment =  new enrollmentModel();
      $enrollment = new enrollment();
      $this->obstud =  new studentsModel();
      $this->obcourse =  new courseModel();
      $this->config = new config; 
      $error_msg = '';
		}
    // Request handler
    public function requestHandler() 
    {
      global $action,$error_msg,$enrollment;
      $todo = isset($_GET['todo']) ? $_GET['todo'] : NULL;
      $action = "index.php?route=studenttocourse&todo=add";
      try
      {
        switch ($todo) 
        {
          case 'add' :
              $this->addEnrollment();
            break;            
          case 'update':
            $this->updateEnrollment();
            break;        
          case 'delete' :         
            $this->deleteEnrollment();
            break;
          case 'report' :         
            $this->getReport();
            $action = "index.php?route=report&todo=report";
            break;                
          default:
            $this->enrollmentList();
        }
      }catch(Exception $e){
        $error_msg="Error description: ".$e->getMessage();                  
        $this->enrollmentList();
      }
    } 	

    // add enrollment record
		public function addEnrollment()
		{
      global $message,$enrollment,$error_msg;
            try{
                $enrollment = new enrollment();
                  // read form value
                  $enrollment->student_ids =$_POST['filter_student'];
                  $enrollment->course_ids = $_POST['filter_course'];
                  $rec_count = count($enrollment->student_ids);
                  //call validation
                          
                  $pid = $this->obenrollment->addEnrollment($enrollment);
                  if($pid == $rec_count && $rec_count > 0){	
                    $enrollment = NULL;
                    $message= "enrollment added successfully!";
                  }else if( $pid < $rec_count && $pid > 0){
                    $error_msg= "Found duplicate entries ! Records added Partially! ";
                  }else if($rec_count > 0){
                    $error_msg= "Trying to add duplicate entries !";
                  }
                  $this->enrollmentList();
                  
            }catch (Exception $e) 
            {
                throw $e;
            }
        }

   // Delete enrollment record
    
    public function deleteEnrollment()
    {
      global $message,$enrollment,$error_msg;
            try{
                $enrollment = new enrollment();
                  // read form value
                  $enrollment_id = trim($_GET['id']);
                  if($enrollment_id)
                  {
                      // insert enrollment record            
                      $resp = $this->obenrollment->deleteEnrollment($enrollment_id);
                      if($resp){ 
                        $message= "enrollment deleted successfully!";
                      }else{
                        $error_msg= "Error while deleting record!";
                      }
                  }else{
                    $error_msg=" Invalid record!";
                  }
                  $this->enrollmentList();
            }catch (Exception $e) 
            {
                throw $e;
            }
      }
      //Get List of students enrolled
        public function enrollmentList(){
            global $message,$enrollment,$error_msg,$action,$pageno,$total_pages;
            $result = array();
            $studentResult = array();
            $courseResult = array();
            try{
              if (isset($_GET['pageno'])) {
                  $pageno = $_GET['pageno'];
              } else {
                  $pageno = 1;
              }
              
              $offset = ($pageno-1) * $this->config->page_record_count;

              $total_rows=$this->obenrollment->getEnrollmentCount();
              $total_pages = ceil($total_rows / $this->config->page_record_count);

              $result=$this->obenrollment->getEnrollments($offset,$this->config->page_record_count);
              $studentResult=$this->obstud->getAllStudents();
              $courseResult=$this->obcourse->getAllCourses();
            // var_dump($result);

              include "view/enrollmentList.php";                                        
            }catch(Exception $e){
              $error_msg="Error description: ".$e->getMessage();                  
              include "view/enrollmentList.php";
            }
        }
        //Report list
        public function getReport(){
            global $message,$enrollment,$error_msg,$action,$pageno,$total_pages;
            $result = array();
            try{
              if (isset($_GET['pageno'])) {
                  $pageno = $_GET['pageno'];
              } else {
                  $pageno = 1;
              }
              $offset = ($pageno-1) * $this->config->page_record_count;

              $total_rows=$this->obenrollment->getReportCount();
              $total_pages = ceil($total_rows / $this->config->page_record_count);

              $result=$this->obenrollment->getStudentReport($offset,$this->config->page_record_count);
         
              include "view/report.php";                                        
            }catch(Exception $e){
              $error_msg="Error description: ".$e->getMessage();                  
              include "view/report.php";
            }
        }
    }
		
	
?>