<?php
    require_once 'model/studentsModel.php';
    require_once 'model/students.php';
    require_once "config.php";
    require_once "Controller.php";
        
  $message = ""; 
  $error_msg = "";
  $stud = NULL;
  $action = "";
  $pageno = $total_pages = "";
	class studentsController implements Controller
	{
 		function __construct() 
		{          
			$this->obstud =  new studentsModel();
      $this->config = new config;   
      $error_msg = '';
		}
    // Request handler
    public function requestHandler() 
    {
      global $action,$error_msg;
      $todo = isset($_GET['todo']) ? $_GET['todo'] : NULL;
      $action = "index.php?route=student&todo=add";
      try
      {
        switch ($todo) 
        {
            case 'add' :
              $this->addStudent();
            break;            
          case 'update':
            $this->updateStudent();
            break;        
          case 'delete' :         
            $this->deleteStudent();
            break;                
          default:
                $this->studentList();
        }
      }catch(Exception $e){
        $error_msg="Error description: ".$e->getMessage();                  
        $this->studentList();
      }
    } 	

    function isValidDate($date, $format= 'Y-m-d'){
        return $date == date($format, strtotime($date));
    }
        //  validation of student record data
		public function validationFormdata($stud)
        {    $error=false;
            // Validate fname        
            if(empty($stud->fname)){
                $stud->fname_msg = "Field is empty.";$error=true;
            } elseif(!filter_var($stud->fname, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+[0-9]*[a-zA-Z]*$/")))){
                $stud->fname_msg = "Invalid entry.";$error=true;
            }elseif(strlen($stud->fname) < 3){
                $stud->fname_msg = "Required minimum 3 letters.";$error=true;
            }else{$stud->fname_msg ="";}   
            // Validate lname            
            if(empty($stud->lname)){
                $stud->lname_msg = "Field is empty.";$error=true;     
            } elseif(!filter_var($stud->lname, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z0-9\s]+$/")))){
                $stud->lname_msg = "Invalid entry.";$error=true;
            }else{$stud->lname_msg ="";}

            // Validate dob            
            if(empty($stud->dob)){
                $stud->dob_msg = "Field is empty.";$error=true;     
            } elseif(!$this->isValidDate($stud->dob)){
                $stud->dob_msg = "Invalid entry.";$error=true;
            }else{
              if(date('Y-m-d',time()) <= date('Y-m-d',strtotime($stud->dob))){
                
                $stud->dob_msg = "Invalid Date , should be less then current date.";$error=true;
              }else{
                $stud->dob_msg ="";
            }
          }
            // Validate contact_no           
            if(empty($stud->contact_no)){ 
                $stud->contact_no_msg = "Field is empty.";$error=true;     
            } elseif(!preg_match('/^\d{10}$/',$stud->contact_no)){
                $stud->contact_no_msg = "Invalid entry.";$error=true;
            }else{$stud->contact_no_msg ="";}

            // var_dump("expression");         

            return $error;
        }
        // add student record
		public function addStudent()
		{
      global $message,$stud,$error_msg;
            try{
                $stud = new students();
                  // read form value
                  $stud->fname = trim($_POST['fname']);
                  $stud->lname = trim($_POST['lname']);
                  $stud->dob = trim($_POST['dob']);
                  $stud->contact_no = trim($_POST['contact_no']);
                  //call validation
                  if(!$this->validationFormdata($stud))
                  {   
                      //Check contact number to avoid duplicate entry
                      if($this->obstud->checkContactNo($stud->contact_no)==0)
                      {
                        // insert student record            
                        $pid = $this->obstud->addStudent($stud);
                        if($pid>0){	
                          $stud = NULL;
                          $message= "Student added successfully!";
                        }else{
                          $error_msg= "Somthing is wrong..., try again.";
                        }
                      }else{
                        $stud->contact_no_msg = "Duplicate no!";
                        $error_msg= "Contact no already exist!";
                      }
                  }else
                  {    
                      $error_msg="Error in the form input!";
                  }
                  $this->studentList();
            }catch (Exception $e) 
            {

                throw $e;
            }
        }

    // update student record
    public function updateStudent()
    {
      global $message,$stud,$error_msg;
            try{
                $stud = new students();
                  // read form value
                  $stud->fname = trim($_POST['fname']);
                  $stud->lname = trim($_POST['lname']);
                  $stud->dob = trim($_POST['dob']);
                  $stud->contact_no = trim($_POST['contact_no']);
                  $stud->stud_id = trim($_POST['id']);
                  if($stud->stud_id)
                  {
                    //call validation
                    if(!$this->validationFormdata($stud))
                    {   
                          // insert student record            
                          $resp = $this->obstud->updateStudent($stud);
                          if($resp){ 
                            $stud = NULL;
                            $message= "Student updated successfully!";
                          }else{
                            $error_msg= "Somthing is wrong..., try again.";
                          }
                       
                    }else
                    {    
                        $error_msg="Error in the form input!";
                    }
                  }else{
                    $error_msg="Invalid record!";
                  }
                  $this->studentList();
            }catch (Exception $e) 
            {
                $error_msg="Error description: ".$e->getMessage();                  
                $this->studentList();
            }
        }
    //Delete student
    public function deleteStudent()
    {
      global $message,$stud,$error_msg;
            try{
                $stud = new students();
                  // read form value
                  $stud_id = trim($_GET['id']);
                  if($stud_id)
                  {
                      // insert student record            
                      $resp = $this->obstud->deleteStudent($stud_id);
                      if($resp){ 
                        $message= "Student deleted successfully!";
                      }else{
                        $error_msg= "Error while deleting record!";
                      }
                  }else{
                    $error_msg=" Invalid record!";
                  }
                  $this->studentList();
            }catch (Exception $e) 
            {
                throw $e;
            }
      }

      public function studentList(){
            global $message,$stud,$error_msg,$action,$pageno,$total_pages;
            $result = array();
            try{
              if (isset($_GET['pageno'])) {
                  $pageno = $_GET['pageno'];
              } else {
                  $pageno = 1;
              }
              $offset = ($pageno-1) * $this->config->page_record_count;

              $total_rows=$this->obstud->getStudentCount();
              $total_pages = ceil($total_rows / $this->config->page_record_count);
              $result=$this->obstud->getStudents($offset,$this->config->page_record_count);
              include "view/studentList.php";                                        
            }catch(Exception $e){
              $error_msg="Error description: ".$e->getMessage();                  
              include "view/studentList.php";
            }
        }
    }
		
	
?>