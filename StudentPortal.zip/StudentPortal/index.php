<?php
	$route = $_GET['route'];
	switch ($route) {
		case 'report':
			require_once  'controller/enrollmentController.php';		
		    $controller = new enrollmentController();
		    $controller->requestHandler();
			break;
		case 'course':
			require_once  'controller/courseController.php';		
		    $controller = new courseController();	
		    $controller->requestHandler();
			break;
		case 'studenttocourse':
			require_once  'controller/enrollmentController.php';		
		    $controller = new enrollmentController();	
		    $controller->requestHandler();
			break;
		default:
		// var_dump("expression11");
			require_once  'controller/studentsController.php';		
		    $controller = new studentsController();	
		    $controller->requestHandler();
			break;
	}
	
?>