<?php
require_once "config.php";
class DBhandler
	{
		private static $db = NULL;
		private $conn = NULL;
		private $config = NULL;
		// set DBhandler contruction in private access to aviod creating object from outside the class
		private function __construct()
		{
			$this->config = new config;		
		}
		private function __clone() { 
			throw new Exception("Can't clone Mysql Connection");
		}
		//
		private function createDBConnection() {

			$this->conn=new mysqli($this->config->host,$this->config->user,$this->config->pass,$this->config->db_name);
			if ($this->conn->connect_error) 
			{
    			throw new Exception($this->conn->connect_error);
    			  
			}
		}
	    //get singleton instance to DBhandler 
		public static function getInstance() :mysqli {
	        if (NULL == self::$db) {
	            self::$db = new DBhandler();
	        	self::$db->createDBConnection();
	        	if(self::$db->conn){
	        		return self::$db->conn;
	        	}else{
	        		throw new Exception("Failed to create connection!");
	        	}
	        }
	        return self::$db->conn;
	    }
	  
	    // close database
	    public function closeConnection()
		{
			$this->conn->close();
		}

		function __destruct() {
		   $this->closeConnection();
		}
	   
	}

?>