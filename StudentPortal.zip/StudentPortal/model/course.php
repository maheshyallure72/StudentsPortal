<?php

class course
{
    // course fields
    public $course_name;
    public $course_details;
    public $course_id;
    // message string
    public $course_name_msg;
    public $course_details_msg;
    // constructor set default value
    public function __construct()
    {
        $course=$course_details="";
        $course_name_msg=$course_details_msg="";
    }
}

?>