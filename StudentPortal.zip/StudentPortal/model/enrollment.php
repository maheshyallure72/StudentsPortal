<?php

class enrollment
{
    // enrollment fields
    public $student_ids;
    public $course_ids;
    
    // message string
    public $student_id_msg;
    public $course_id_msg;
    // constructor set default value
    public function __construct()
    {
        $student_ids=$course_ids="";
        $student_id_msg=$course_id_msg="";
    }
}

?>