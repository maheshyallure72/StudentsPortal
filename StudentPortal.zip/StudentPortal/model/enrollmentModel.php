<?php
	require_once "DBhandler.php";
	class enrollmentModel
	{
		private $conn = NULL;
		// get connection object
		function __construct()
		{
			$this->conn = DBhandler::getInstance();
			if(!$this->conn){
				throw new Exception("Failed to create DB instance!");
			}
		}
		// insert record
		public function addEnrollment(&$obj)
		{
			$insert_count = 0;
			try
			{	
				foreach ($obj->student_ids as $key => $student_id ) {
					if(!$this->checkDuplicate($student_id,$obj->course_ids[$key]))
					{
						$this->conn->query("START TRANSACTION");
						$query=$this->conn->prepare("INSERT INTO enrollment(`stud_id`, `course_id`) VALUES  (?, ?)");
						if($query)
						{
							$query->bind_param("ii",$student_id,$obj->course_ids[$key]);
							if($query->execute())
							{
								$insert_count +=1;
								$query->close();
							}else{
								throw new Exception("Failed to create DB instance!");
							}
						}else{
							throw new Exception(mysqli_error($this->conn));
						}

						$query=$this->conn->prepare("UPDATE course SET total_enrollment=(total_enrollment+1) WHERE course_id = ? ");
						if($query)
						{
							$query->bind_param("i",$obj->course_ids[$key]);
							$query->execute();
							$query->close();
						}else{
							throw new Exception(mysqli_error($this->conn));
						}
						$this->conn->query("COMMIT");
						unset($obj->student_ids[$key]);
						unset($obj->course_ids[$key]);

					}
				}
				return $insert_count;
			}
			catch (Exception $e) 
			{
				$this->conn->query("ROLLBACK");
            	throw $e;
        	}
		}
		public function checkDuplicate($stud_id,$course_id){
			try
			{
				$is_exist = 0;
				
                $query=$this->conn->prepare("SELECT stud_id FROM enrollment where stud_id = ? AND course_id = ?");
				if($query)
				{
					$query->bind_param("ii",$stud_id,$course_id);
					if($query->execute())
					{
						$res=$query->get_result();	
						$is_exist = $res->num_rows;		
					}
					$query->close();		
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
				return $is_exist;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
		}
  //       //update record
		public function updateEnrollment($obj)
		{
			$updated = 0;
			try
			{	
				$resp['error'] = false;
				
				$query=$this->conn->prepare("UPDATE enrollment SET cname = ? , cdetails = ? WHERE course_id = ? ");
				if($query)
				{
					$query->bind_param("ssi",$obj->course_name,$obj->course_details,$obj->course_id);
					if($query->execute())
					{
						$query->close();
						$updated = 1;
					}else{
						throw new Exception(mysqli_error($this->conn));
					}
				}else{
					throw new Exception(mysqli_error($this->conn));
					
				}
				return $updated;
			}
			catch (Exception $e) 
			{

            	throw $e;
        	}
		}

		public function deleteEnrollment($enrollment_id)
		{
			$deleted = 0;
			try
			{	
				
				$this->conn->query("START TRANSACTION");
				$query=$this->conn->prepare("UPDATE course c LEFT JOIN enrollment e ON c.course_id = e.course_id SET c.total_enrollment=(c.total_enrollment-1) WHERE e.id = ? ");
				if($query)
				{
					$query->bind_param("i",$enrollment_id);
					if(!$query->execute()){
						throw new Exception(mysqli_error($this->conn));
					}
					$query->close();
				}else{
					throw new Exception(mysqli_error($this->conn));
				}
				$query=$this->conn->prepare("DELETE FROM enrollment WHERE id = ? ");
				if($query)
				{
					$query->bind_param("i",$enrollment_id);
					if($query->execute())
					{
						$res= $query->get_result();
						$query->close();
						$deleted = 1;
					}else{
						throw new Exception(mysqli_error($this->conn));
					}
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
				$this->conn->query("COMMIT");
			}
			catch (Exception $e) 
			{
				$this->conn->query("ROLLBACK");
				throw $e;
        	}
        	return $deleted;
		}
		
        // select record     
		public function getEnrollments($start,$limit)
		{
			$response = array();
			try
			{
				
                $query=$this->conn->prepare("SELECT e.*,CONCAT( s.fname,' ',s.lname) as stud_name,c.cname FROM enrollment e LEFT JOIN course c ON e.course_id = c.course_id LEFT JOIN students s ON s.stud_id = e.stud_id order by course_id desc LIMIT $start,$limit");			
				if($query)
				{
					if($query->execute())
					{
						$res=$query->get_result();
						$response = mysqli_fetch_all($res, MYSQLI_ASSOC);
						mysqli_free_result($res);  	
					}
					$query->close();				
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
                return $response;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
		  // select record for report    
		public function getStudentReport($start,$limit)
		{
			$response = array();
			try
			{
				
                $query=$this->conn->prepare("SELECT s.stud_id,CONCAT( s.fname,' ',s.lname) as stud_name,IF(c.course_id IS NULL,'NA',c.course_id) AS course_id ,IF(c.cname IS NULL,'NA',c.cname) AS cname,IF(e.date_added IS NULL,'NA',e.date_added) AS date_added FROM students s LEFT JOIN enrollment e ON s.stud_id = e.stud_id LEFT JOIN course c ON e.course_id = c.course_id LIMIT $start,$limit");			
				if($query)
				{
					if($query->execute())
					{
						$res=$query->get_result();
						$response = mysqli_fetch_all($res, MYSQLI_ASSOC);
						mysqli_free_result($res);  	
					}
					$query->close();				
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
                return $response;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
		  // select total count for pagination     
		public function getEnrollmentCount()
		{
			try
			{
                $query=$this->conn->prepare("SELECT count(*) AS count FROM enrollment ");		
				if($query)
				{
					$query->execute();
					$res=$query->get_result();	
					if($row = mysqli_fetch_array($res)){
						return $row['count'];
					}else{
						return 0;
					}	
					$query->close();				
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
                return 0;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}

		// select total count for report pagination     
		public function getReportCount()
		{
			try
			{
				
                $query=$this->conn->prepare("SELECT count(*) AS count  FROM students s LEFT JOIN enrollment e ON s.stud_id = e.stud_id LEFT JOIN course c ON e.course_id = c.course_id");			
				if($query)
				{
					if($query->execute())
					{
						$res=$query->get_result();	
						if($row = mysqli_fetch_array($res)){
							return $row['count'];
						}
					}	
					$query->close();				
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
                return 0;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
		
	}

?>