<?php

class students
{
    // table fields
    public $fname;
    public $lname;
    public $dob;
    public $contact_no;
    public $stud_id;
    // message string
    public $fname_msg;
    public $lname_msg;
    public $dob_msg;
    public $contact_no_msg;
    // constructor set default value
    public function __construct()
    {
        $fname=$lname=$dob=$contact_no=$stud_id="";
        $dob_msg=$fname_msg=$lname_msg=$contact_no_msg="";
    }
}

?>