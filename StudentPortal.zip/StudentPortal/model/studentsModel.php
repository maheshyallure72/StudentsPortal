<?php
	require_once "DBhandler.php";
	class studentsModel
	{
		private $conn = NULL;
		// get connection object
		function __construct()
		{
			$this->conn = DBhandler::getInstance();
			if(!$this->conn){
				throw new Exception("Failed to create DB instance!");
			}
		}
			
		// insert record
		public function addStudent($obj)
		{
			$last_id = 0;
			try
			{	
				$query=$this->conn->prepare("INSERT INTO students(`fname`, `lname`, `dob`, `contact_no`) VALUES  (?, ?,?,?)");
				if($query)
				{
					$query->bind_param("sssi",$obj->fname,$obj->lname,$obj->dob,$obj->contact_no);
					if($query->execute())
					{
						$last_id=$this->conn->insert_id;
						$query->close();
					}else{
						throw new Exception("Failed to create DB instance!");
					}
				}else{
					throw new Exception(mysqli_error($this->conn));
				}
				return $last_id;
			}
			catch (Exception $e) 
			{
            	throw $e;
        	}
		}
  //       //update record
		public function updateStudent($obj)
		{
			$updated = 0;
			try
			{	
				$resp['error'] = false;
				$query=$this->conn->prepare("UPDATE students SET fname = ? , lname = ?, dob = ? , contact_no = ? WHERE stud_id = ? ");
				if($query)
				{
					$query->bind_param("sssii",$obj->fname,$obj->lname,$obj->dob,$obj->contact_no,$obj->stud_id);
					if($query->execute())
					{
						$query->close();
						$updated = 1;
					}else{
						throw new Exception(mysqli_error($this->conn));
					}
				}else{
					throw new Exception(mysqli_error($this->conn));
					
				}
				return $updated;
			}
			catch (Exception $e) 
			{

            	throw $e;
        	}
		}

		public function deleteStudent($stud_id)
		{
			$deleted = 0;
			try
			{	
				$query=$this->conn->prepare("DELETE FROM students WHERE stud_id = ? ");
				if($query)
				{
					$query->bind_param("i",$stud_id);
					if($query->execute())
					{
						$query->close();
						$deleted = 1;
					}else{
						throw new Exception(mysqli_error($this->conn));
					}
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
			}
			catch (Exception $e) 
			{
				throw $e;
        	}
        	return $deleted;
		}
		
  //       // select record     
		public function getStudents($start,$limit)
		{
			$response = array();
			try
			{
				$sql_query ='call getDetails("students","stud_id",'.(int)$start.','.(int)$limit.')';
				$res=$this->conn->query($sql_query);
				if($res){
					$response = mysqli_fetch_all ($res, MYSQLI_ASSOC);
					mysqli_free_result($res);  
				}
				else{
					throw new Exception(mysqli_error($this->conn));
				}

                return $response;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}

		// select ALL record     
		public function getAllStudents()
		{
			$response = array();
			try
			{
                $query=$this->conn->prepare("SELECT stud_id, fname, lname FROM students order by stud_id desc");			
				if($query)
				{
					if($query->execute())
					{
						$res=$query->get_result();
						$response = mysqli_fetch_all($res, MYSQLI_ASSOC);
						mysqli_free_result($res);  	
					}
					$query->close();				
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
                return $response;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
		  // select total count for pagination     
		public function getStudentCount($start,$limit)
		{
			try
			{
                $query=$this->conn->prepare("SELECT count(*) AS count FROM students ");	
				if($query)
				{
					if($query->execute())
					{
						$res =$query->get_result(); 
						if($row = mysqli_fetch_array($res)){
							return $row['count'];
						}else{
							return 0;
						}
					}	
					$query->close();				
				}else{
					throw new Exception(mysqli_error($this->conn));
				}
                return 0;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
		public function checkContactNo($contact_no){
			try
			{
				$is_exist = 0;
                $query=$this->conn->prepare("SELECT stud_id FROM students where contact_no = ?");
				if($query)
				{
					$query->bind_param("i",$contact_no);
					if($query->execute()){
						$res =$query->get_result(); 
						$is_exist = $res->num_rows;		
					}
					$query->close();			
					
				}else{
					throw new Exception( mysqli_error($this->conn));
				}
				return $is_exist;
			}
			catch(Exception $e)
			{
				throw $e; 	
			}
			
		}
	}

?>