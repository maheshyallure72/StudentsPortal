<!DOCTYPE html>
<head>
   <?php include_once('header.php'); ?>
</head>
<body>
   <div class="wrapper">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="page-header">
                  <h2 class="center-block" >Course Details</h2>
               </div>
               <div class="form" >
                  <form action="index.php?route=course&todo=add" name="course_data" method="post" style="width: 50%;">
                     <input type="hidden" name="id" class="form-control" value="<?php echo $course->course_id; ?>" >
                     <label>Course Name</label>
                     <input type="textarea" name="cname" class="form-control" value="<?php echo $course->course_name; ?>">
                     <span class="help-block error"><?php echo $course->course_name_msg;?></span>
                     <label>Course Details</label>
                     <input type="text" name="cdetails" class="form-control" value="<?php echo $course->course_details; ?>">
                     <span class="help-block error"><?php echo $course->course_details_msg;?></span>
                     <input type="submit" name="Submit" class="btn btn-success center-block">
                  </form>
               </div>
               <div>
                  <br/><br/>
                  <?php if($error_msg) { ?>
                  <div class="alert alert-warning center-block"><?php echo $error_msg; ?></div>
                  <?php } else if($message) { ?>
                  <div class="alert alert-success center-block"><?php echo $message; ?></div>
                  <?php } ?>
                  <br/><br/>
               </div>
               <table class='table table-bordered table-striped'>
                  <thead>
                     <tr>
                        <th>ID</th>
                        <th>Course Name</th>
                        <th>Course Details</th>
                        <th>Total Enrolled</th>
                        <th>Delete</th>
                        <th>Edit</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(count($result) > 0){
                        foreach($result as $row){ ?>
                     <tr>
                        <td> <?php echo $offset+=1; ?></td>
                        <td><?php echo $row['cname'] ?></td>
                        <td><?php echo $row['cdetails'] ?></td>
                        <td><?php echo $row['total_enrollment'] ?></td>
                        <td><a onclick="update(<?php echo $row['course_id'] ?>,'<?php echo $row['cname'] ?>','<?php echo $row['cdetails'] ?>')"  title="Edit" >Edit</a></td>
                        <td>
                           <a onclick="deleteStud(<?php echo $row['course_id'] ?>);" title='Delete Record'>Delete</a>
                        </td>
                     </tr>
                     <?php   } ?>
                  </tbody>
               </table>
               <?php } else{ ?>
               </tbody>                            
               </table>
               <p class='lead'><em>No records were found.</em></p>
               <?php } ?>
            </div>
            <?php if( count($result) > 0){ ?>
            <div align="center">
               <ul class="pagination" >
                  <li><a href="?route=course&pageno=1">First</a></li>
                  <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?route=course&pageno=".($pageno - 1); } ?>">Prev</a>
                  </li>
                  <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?route=course&pageno=".($pageno + 1); } ?>">Next</a>
                  </li>
                  <li><a href="?route=course&pageno=<?php echo $total_pages; ?>">Last</a></li>
                  <li >Showing <?php echo $pageno; ?> of <?php echo $total_pages; ?></li>
               </ul>
            </div>
            <?php } ?>
         </div>
      </div>
   </div>
</body>
<script type="text/javascript">
   $( document ).ready(function() {
       $("[name='course_data']").attr('action', '<?php echo $action; ?>');
   });
   // $('#dob').datepicker({ dateFormat: 'yy-mm-dd' });
   function deleteStud(course_id) {
       if(confirm("This will delete records from enrollment if course is enrolled by any of student! , Do you want to continue?")){
           window.location.href ='index.php?route=course&todo=delete&id='+course_id;
       }
   }
   function update(course_id,cname,cdetails) {
       $("[name='course_data']").attr('action', 'index.php?route=course&todo=update');
       $("[name='id']").val(course_id);
       $("[name='cname']").val(cname);
       $("[name='cdetails']").val(cdetails);
   }
   
</script>
</html>