<!DOCTYPE html>
<head>
   <?php include_once('header.php'); ?>
</head>
<body>
   <div class="wrapper">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
              <div class="page-header">
                  <h2 class="center-block" >Enrollment Details</h2>
               </div>
               <div class="form" >
                  <form action="index.php?route=studenttocourse&todo=add" name="enrollment_data" method="post" >
                     <button id="btnAddRow" type="button" style="float: right;">Add Row</button>
                     </br></br>
                     <table id="tblAddRow" border="1" style="width: 100%;">
                        <thead>
                           <tr>
                              <th style="text-align: center;">Student</th>
                              <th style="text-align: center;">Course</th>
                              <th style="text-align: center;">Action</th>
                           </tr>
                        </thead>
                        <tbody id="list">
                           <tr>
                              <td>
                                 <select id="filter_student" name="filter_student[]" class="form-control">
                                    <?php if(count($studentResult) > 0){?>
                                    <?php foreach($studentResult as $row){  ?> 
                                    <option value="<?php echo $row['stud_id'];?>"><?php echo $row['fname'].' '.$row['lname'];?></option>
                                    <?php } }?>    
                                 </select>
                              </td>
                              <td>
                                 <select id="filter_course" name="filter_course[]" class="form-control">
                                    <?php if(count($courseResult) > 0){?>
                                    <?php foreach($courseResult as $row){  ?> 
                                    <option value="<?php echo $row['course_id'];?>"><?php echo $row['cname']?></option>
                                    <?php } }?>    
                                 </select>
                              </td>
                              <td style="text-align:center;"><a href="#" class="delrow">Delete Row</a></td>
                           </tr>
                        </tbody>
                     </table>
                     </br></br>
                     <input type="submit" name="Submit" class="btn btn-success center-block"> 
                  </form>
               </div>
               <div>
                  <br/><br/>
                  <?php if($error_msg) { ?>
                  <div class="alert alert-warning center-block"><?php echo $error_msg; ?></div>
                  <?php } else if($message) { ?>
                  <div class="alert alert-success center-block"><?php echo $message; ?></div>
                  <?php } ?>
                  <br/><br/>
               </div>
                  <table class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th>S.No</th>
                        <th>Student Name</th>
                        <th>Course Name</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                  <tbody>
                  <?php if(count($result) > 0){
                    foreach($result as $row){ ?>
                        <tr>
                          <td><?php echo $offset+=1; ?></td>
                          <td><?php echo $row['stud_name']; ?></td>
                          <td><?php echo $row['cname']; ?></td>
                          <td>
                          <a onclick="deleteStud('<?php echo $row["id"] ?>');" title='Delete Record'>Delete</a></td>
                        </tr>
                    <?php } ?>
                    </tbody>                            
                  </table>
                      
                  <?php } else{ ?>
                  </tbody>                            
                </table>
                    <p class='lead'><em>No records were found.</em></p>
                  <?php }?>
            </div>
            <?php if(count($result) > 0){ ?>
            <div align="center">
               <ul class="pagination" >
                  <li><a href="?route=studenttocourse&pageno=1">First</a></li>
                  <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?route=studenttocourse&pageno=".($pageno - 1); } ?>">Prev</a>
                  </li>
                  <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?route=studenttocourse&pageno=".($pageno + 1); } ?>">Next</a>
                  </li>
                  <li><a href="?route=studenttocourse&pageno=<?php echo $total_pages; ?>">Last</a></li>
                  <li >Showing <?php echo $pageno; ?> of <?php echo $total_pages; ?></li>
               </ul>
            </div>
            <?php } ?>
         </div>
      </div>
   </div>
</body>
<script type="text/javascript">
   $( document ).ready(function() {
       $("[name='enrollment_data']").attr('action', '<?php echo $action; ?>');
   });
   $('#dob').datepicker({ dateFormat: 'yy-mm-dd' });
   function deleteStud(enrl_id) {
       if(confirm("Do you want to delete enrollment!")){
           window.location.href ='index.php?route=studenttocourse&todo=delete&id='+enrl_id;
       }
   }
   
</script>
<script>
    $('#btnAddRow').on('click', function() {
       var lastRow = $('#tblAddRow tbody tr:last').html();
       $('#tblAddRow tbody').append('<tr>' + lastRow + '</tr>');
       $('#tblAddRow tbody tr:last input').val('');
    });
   
   $('#tblAddRow').on('click', 'tr a', function(e) {
       var lenRow = $('#tblAddRow tbody tr').length;
       // e.preventDefault();
       if (lenRow == 1 || lenRow <= 1) {
           alert("Minimum one row is required!");
       } else {
           $(this).parents('tr').remove();
       }
   });
   
</script>
</html>