<!DOCTYPE html>
<head>
   <title>Dashboard</title>
   <link rel="stylesheet" href="~/../libs/bootstrap.css">
   <script src="~/../libs/jquery.min.js"></script>
   <script src="~/../libs/bootstrap.js"></script>
   <style type="text/css">
   .header {
      overflow: hidden;
      background-color: #f1f1f1;
      padding: 20px 10px;
   }
   .header-right {
      float: right;
   }
   .error{
      color: red;
   }
  </style>
   <!-- TODO -->
   <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <link rel="stylesheet" href="/resources/demos/style.css"> -->
   <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
   <!-- <style type="text/css">
      .header {
      overflow: hidden;
      background-color: #f1f1f1;
      padding: 20px 10px;
      }
      .header-right {
      float: right;
      }
   </style> -->
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="page-header">
            <div class="header">
              <div class="header-right">
                <button> <a class="active" href="index.php?route=student">Student Home</a>
                </button>
                <button><a href="index.php?route=course">Courses</a></button>
                <button><a href="index.php?route=studenttocourse">Enrollment</a></button>
                <button><a href="index.php?route=report&todo=report">Report</a></button>
              </div>
            </div>   
          </div>
        </div>
      </div>
    </div>
</head>
