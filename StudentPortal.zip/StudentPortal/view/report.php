<!DOCTYPE html>
<head>
   <?php include_once('header.php'); ?>
</head>
<body>
   <div class="wrapper">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="page-header">
                  <h2 class="center-block" >Report</h2>
                </div>
                <table class='table table-bordered table-striped'>
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Student Name</th>
                      <th>Course Name</th>
                      <th>Enrolled Date</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if( count($result) > 0){ 
                      foreach($result as $row){ ?>
                    <tr>
                        <td><?php echo $offset+=1; ?> </td>
                        <td><?php echo $row['stud_name']; ?></td>
                        <td><?php echo $row['cname']; ?> </td>
                        <td><?php echo $row['date_added']; ?> </td>
                    </tr>
                    <?php } ?>
                  </tbody>                            
                </table>
              <?php } else{ ?>
                </tbody>                            
              </table>
              <p class='lead'><em>No records were found.</em></p>
              <?php } ?> 
            </div>
            <?php if(count($result) > 0){ ?>
            <div align="center">
               <ul class="pagination" >
                  <li><a href="?route=report&todo=report&pageno=1">First</a></li>
                  <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?route=report&todo=report&pageno=".($pageno - 1); } ?>">Prev</a>
                  </li>
                  <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?route=report&todo=report&pageno=".($pageno + 1); } ?>">Next</a>
                  </li>
                  <li><a href="?route=report&todo=report&pageno=<?php echo $total_pages; ?>">Last</a></li>
                  <li >Showing page <?php echo $pageno; ?> of <?php echo $total_pages; ?></li>
               </ul>
            </div>
            <?php }             ?> 
         </div>
      </div>
   </div>
</body>
</html>