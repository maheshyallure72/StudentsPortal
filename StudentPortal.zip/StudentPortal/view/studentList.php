<!DOCTYPE html>
<head>
<?php include_once('header.php'); ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>
<body>
   <div class="wrapper">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="page-header">
                  <h2 class="center-block" >Student Details</h2>
               </div>
               <div class="form" style="width: 50%;">
                  <form action="index.php?route=student&todo=add" name="stud_data" method="post" >
                     <input type="hidden" name="id" class="form-control" value="<?php echo $stud->stud_id; ?>" >
                     <label>Firstname</label>
                     <input type="text" name="fname" class="form-control" value="<?php echo $stud->fname; ?>">
                     <span class="help-block error"><?php echo $stud->fname_msg;?></span>
                     <label>Lastname</label>
                     <input type="text" name="lname" class="form-control" value="<?php echo $stud->lname; ?>">
                     <span class="help-block error"><?php echo $stud->lname_msg;?></span>
                     <label>DOB</label>
                     <input type="text" name="dob" id="dob" class="form-control" value="<?php echo $stud->dob; ?>" readonly="readonly">
                     <span class="help-block error"><?php echo $stud->dob_msg;?></span>
                     <label>Contact No</label>
                     <input type="number" name="contact_no" class="form-control" value="<?php echo $stud->contact_no; ?>">
                     <span class="help-block error"><?php echo $stud->contact_no_msg;?></span>
                     <input type="submit" name="Submit" class="btn btn-success center-block">
                  </form>
               </div>
               <div>
                  <br/><br/>
                  <?php if($error_msg) { ?>
                  <div class="alert alert-warning center-block"><?php echo $error_msg; ?></div>
                  <?php } else if($message) { ?>
                  <div class="alert alert-success center-block"><?php echo $message; ?></div>
                  <?php } ?>
                  <br/><br/>
               </div>
               <table class='table table-bordered table-striped'>
                  <thead>
                     <tr>
                        <th>S.No</th>
                        <th>Firstame</th>
                        <th>Lastname</th>
                        <th>DOB</th>
                        <th>Contact No</th>
                        <th>Edit</th>
                        <th>Delete</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php if(count($result) > 0){
                        foreach($result as $row){ ?>
                     <tr>
                        <td><?php echo $offset+=1; ?></td>
                        <td><?php echo $row['fname'] ?></td>
                        <td><?php echo $row['lname'] ?></td>
                        <td><?php echo $row['dob'] ?></td>
                        <td><?php echo $row['contact_no'] ?></td>
                        <td><a onclick="update(<?php echo $row['stud_id'] ?>,'<?php echo $row["fname"]?>','<?php echo $row["lname"]?>','<?php echo $row["dob"]?>',<?php echo $row["contact_no"]?>);"     title='Edit' >Edit</a> </td>
                        <td>
                           <a onclick="deleteStud(<?php echo $row['stud_id'] ?>);" title='Delete Record'>Delete</a>
                        </td>
                     </tr>
                     <?php }?>
                  </tbody>
               </table>
               <?php  } else{ ?>
               </tbody>                            
               </table>
               <p class='lead'><em>No records were found.</em></p>
               <?php } 
                  ?>
            </div>
            <div align="center">
               <ul class="pagination" >
                  <li><a href="?pageno=1">First</a></li>
                  <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>                        
                  </li>
                  <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                     <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
                  </li>
                  <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
                  <li >Showing <?php echo $pageno; ?> of <?php echo $total_pages; ?></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</body>
<script type="text/javascript">
   $( document ).ready(function() {
       $("[name='stud_data']").attr('action', '<?php echo $action; ?>');
   });
   $('#dob').datepicker({ dateFormat: 'yy-mm-dd' });
   function deleteStud(stud_id) {
       if(confirm("This will delete records from enrollment if student is enrolled to any of course, Do you want to continue?")){
           window.location.href ='index.php?route=student&todo=delete&id='+stud_id;
       }
   }
   function update(stud_id,fname,lname,dob,contact_no) {
       $("[name='stud_data']").attr('action', 'index.php?route=student&todo=update');
       $("[name='id']").val(stud_id);
       $("[name='fname']").val(fname);
       $("[name='lname']").val(lname);
       $("[name='dob']").val(dob);
       $("[name='contact_no']").val(contact_no);
   }
   
</script>
</html>